const submitBtn = document.getElementById("submitBtn");
const message = document.getElementById("message");

function checkForm() {
  const name = document.getElementById("fullName").value;
  const email = document.getElementById("email").value;
  const chosen = document.querySelector('input[name="membership"]:checked');

  if (name === "") {
    message.textContent = "Please enter your full name.";
    message.style.color = "red";
  } else if (email === "" || !email.includes("@")) {
    message.textContent = "Please enter a valid email address.";
    message.style.color = "red";
  } else if (chosen === null) {
    message.textContent = "Please choose a membership type.";
    message.style.color = "red";
  } else {
    message.textContent = "Thank you, " + name + "! You registered as a " + chosen.value + ".";
    message.style.color = "green";
  }
}

submitBtn.addEventListener("click", checkForm);